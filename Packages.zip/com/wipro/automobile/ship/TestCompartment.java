package com.wipro.automobile.ship;
import com.wipro.automobile.ship.compartment;

public class TestCompartment {
    public static void main(String args[]){
        compartment c = new compartment(14.5,23.4,14.6);
        System.out.println(c.toString());
    }
}
