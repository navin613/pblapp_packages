import testPackage.foundation;
public class testFoundation {
    public static void main(String args[]){
        foundation obj = new foundation();
        obj.var4 = 4;
        System.out.println(obj.var4);
    } 
}
