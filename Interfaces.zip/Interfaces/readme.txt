Open src foldedr for program files.
1. LibraryInterfaceDemo.java is question1 solution.

2. while for question2 there is two packages live and music and subpackages inside the music class and solved according to question
   where main function is under live package in Test.java file.